/**
 * LDAP configuration objects.
 */
package com.avaje.ebean.config.ldap;