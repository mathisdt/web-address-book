/**
 * Factories to create validators.
 */
package com.avaje.ebean.validation.factory;