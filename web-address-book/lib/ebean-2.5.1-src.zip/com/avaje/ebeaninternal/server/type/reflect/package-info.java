/**
 * Automatic support for Immutable value objects via reflection.
 */
package com.avaje.ebeaninternal.server.type.reflect;