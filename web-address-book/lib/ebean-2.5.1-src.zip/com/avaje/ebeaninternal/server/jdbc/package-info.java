/**
 * Fixes for Oracle JDBC driver issues etc.
 */
package com.avaje.ebeaninternal.server.jdbc;