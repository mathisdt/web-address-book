/**
 * LDAP query and persist implementation.
 */
package com.avaje.ebeaninternal.server.ldap;