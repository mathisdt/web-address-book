/**
 * LDAP query expressions.
 */
package com.avaje.ebeaninternal.server.ldap.expression;