/**
 * DDL generation.
 */
package com.avaje.ebeaninternal.server.ddl;