/**
 * Default L2 server cache implementation.
 */
package com.avaje.ebeaninternal.server.cache;