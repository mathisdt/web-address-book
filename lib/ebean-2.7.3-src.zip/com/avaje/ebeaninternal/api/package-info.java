/**
 * Internal service API.
 */
package com.avaje.ebeaninternal.api;