package com.avaje.ebeaninternal.api;

public interface SpiTransactionScopeManager {

	public void replace(SpiTransaction t);
}
