/**
 * Lucene search integration.
 */
package com.avaje.ebean.config.lucene;