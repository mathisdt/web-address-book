/**
 * CSV processing objects.
 */
package com.avaje.ebean.text.csv;